<template>
    <div class="hot-list">
        
        <FilmItem :isHot="true" v-for="(item, key) in hotFilms" :key="key"></FilmItem>

    </div>
</template>

<script>

import FilmItem from "./film-item.vue"

export default {
    data: () => {
        return {
            hotFilms: [1,1,1,1,1,1,1,1]
        }
    },
    components: {
        FilmItem
    }
}
</script>

<style>

.hot-list{
    padding:0 10px;
}

</style>
